import React from "react";

function Header() {
  return (
    <header>
      <h1>shapeAI Bootcamps</h1>
    </header>
  );
}

export default Header;
